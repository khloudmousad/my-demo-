#!/bin/bash
echo "Compiling..."
javac src/Hello.java -d .
javac test/HelloTest.java -d .
echo "Running Test..."
java HelloTest
