public class HelloTest {
    public static void main(String[] args) {
        String expected = "Hello from Git + Jenkins!";
        if (!expected.equals("Hello from Git + Jenkins!")) {
            System.out.println("Test failed!");
        } else {
            System.out.println("Test passed!");
        }
    }
}
